package ru.vsu.gribanova;

import java.util.Random;

public class Main {

    public static void main(String[] args) {
        Random rnd = new Random();
        int[] arr = new int[10];
        for (int i = 0; i < 10; i++) {
            arr[i] = rnd.nextInt(1000);
            System.out.print(arr[i] + " ");
        }
        System.out.println();
        int[] b = new int[10];
        for (int i = 0; i < 10; i++) {
            b[i] = RSelect(arr.clone(), 0, 9, i);
            System.out.print(b[i] + " ");

        }
    }
    public static int RSelect(int[] arr, int l, int r, int k) {
        int p = (int)(Math.random()* (r - l +1)) + l;
        p = partition(arr, l, r, p);
        if (k == p) return arr[p];
        else if (k > p) return RSelect(arr, p + 1, r, k);
        else return RSelect(arr, l, p - 1, k);
    }

    public static int partition(int[] arr, int l, int r, int p) {
        int pv = arr[p];
        swap(arr, p, r);
        int j = l;
        for (int i = l; i <= r; i++) {
            if (arr[i] < pv) {
                swap(arr, j, i);
                j++;
            }
        }
        swap(arr, r, j);
        return j;
    }

    public static void swap(int[] arr, int f, int s) {
        int x = arr[f];
        arr[f] = arr[s];
        arr[s] = x;
    }
}
